Example 3
=========

Overview:
=========
This example will demonstrate how to use Cron Triggers.


Running the Example:
====================
1. Windows users - Modify the example3.bat file (if necessary) 
to set your JAVA_HOME.  Run example3.bat

2. UNIX/Linux users - Modify the example3.sh file (if necessary)
to set your JAVA_HOME.  Execute example3.sh


Configuration Files:
====================
1.  You can decide to specify a log4j.properties file to
control logging output (optional)
